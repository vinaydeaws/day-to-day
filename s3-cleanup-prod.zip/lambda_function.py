import boto3
from datetime import datetime

def lambda_handler(event, context):
    # S3 client initialize kar
    s3 = boto3.client('s3')
    
    # Bucket naam
    bucket_name = 'prod-db-backup-00'
    
    
    # Event se trigger hui file ka naam (just for logging)
    uploaded_file = event['Records'][0]['s3']['object']['key']
    print(f"New file uploaded: {uploaded_file}")
    
    # Bucket se saari files list kar
    response = s3.list_objects_v2(Bucket=bucket_name)
    
    if 'Contents' not in response:
        print("No files in bucket.")
        return
    
    # Files ko last modified date ke hisaab se sort kar (descending order)
    files = sorted(response['Contents'], key=lambda x: x['LastModified'], reverse=True)
    
    # Total files count
    total_files = len(files)
    print(f"Total files in bucket: {total_files}")
    
    # Agar 2 se zyada files hain, toh latest 2 chhod kar baaki delete kar
    if total_files > 2:
        files_to_delete = files[2:]  # Latest 2 ke baad wali files
        
        for file in files_to_delete:
            file_key = file['Key']
            print(f"Deleting file: {file_key}")
            s3.delete_object(Bucket=bucket_name, Key=file_key)
    
    print("Cleanup complete.")
    return {
        'statusCode': 200,
        'body': 'Cleanup done'
    }